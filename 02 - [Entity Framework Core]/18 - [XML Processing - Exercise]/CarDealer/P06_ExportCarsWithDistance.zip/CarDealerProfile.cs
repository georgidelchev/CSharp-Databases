﻿using AutoMapper;
using CarDealer.Dtos.Export;
using CarDealer.Dtos.Import;
using CarDealer.Models;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            this.CreateMap<ImportSupplierDTO, Supplier>();

            this.CreateMap<ImportPartDTO, Part>();

            this.CreateMap<ImportCustomersDTO, Customer>();

            this.CreateMap<ImportSalesDTO, Sale>();

            this.CreateMap<Supplier, ExportLocalSupplierDTO>()
                .ForMember(x => x.PartsCount, y => y.MapFrom(s => s.Parts.Count));

            this.CreateMap<Car, CarsWithDistanceDTO>();
        }
    }
}

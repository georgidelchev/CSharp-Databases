﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Xml.Serialization;
using AutoMapper;
using CarDealer.Data;
using CarDealer.Dtos.Import;
using CarDealer.Models;

namespace CarDealer
{
    public class StartUp
    {
        private const string DATASETS_DIRECTORY_PATH = "../../../Datasets";


        private const string RESULTS_DIRECTORY_PATH = "../../../Datasets/Results";

        public static void Main(string[] args)
        {
            var db = new CarDealerContext();

            using (db)
            {
                // ResetDatabase(db);

                InitializeMapper();

                // Problem 01 - Import Suppliers
                //var inputXml = File.ReadAllText($"{DATASETS_DIRECTORY_PATH}/suppliers.xml");

                //Console.WriteLine(ImportSuppliers(db, inputXml));

                // Problem 02 - Import Parts
                //var inputXml = File.ReadAllText($"{DATASETS_DIRECTORY_PATH}/parts.xml");

                //Console.WriteLine(ImportParts(db, inputXml));

                // Problem 03 - Import Cars
                //var inputXml = File.ReadAllText($"{DATASETS_DIRECTORY_PATH}/cars.xml");

                //Console.WriteLine(ImportCars(db, inputXml));

                // Problem 04 - Import Customers
                //var inputXml = File.ReadAllText($"{DATASETS_DIRECTORY_PATH}/customers.xml");

                //Console.WriteLine(ImportCustomers(db, inputXml));

                // Problem 05 - Import Sales
                //var inputXml = File.ReadAllText($"{DATASETS_DIRECTORY_PATH}/sales.xml");

                //Console.WriteLine(ImportSales(db, inputXml));
            } 
        }

        // Problem 05 - Import Sales
        public static string ImportSales(CarDealerContext context, string inputXml)
        {
            using (context)
            {
                var xmlSerializer = new XmlSerializer(typeof(List<ImportSalesDTO>), new XmlRootAttribute("Sales"));

                var reader = new StringReader(inputXml);

                using (reader)
                {
                    var saleDtos = (List<ImportSalesDTO>)xmlSerializer.Deserialize(reader);

                    var sales = Mapper.Map<List<Sale>>(saleDtos)
                        .Where(p => context.Cars.Any(c => c.Id == p.CarId)).ToList();

                    context.AddRange(sales);

                    context.SaveChanges();

                    return $"Successfully imported {sales.Count}";
                }
            }
        }

        // Problem 04 - Import Customers
        public static string ImportCustomers(CarDealerContext context, string inputXml)
        {
            using (context)
            {
                var xmlSerializer =
                    new XmlSerializer(typeof(List<ImportCustomersDTO>), new XmlRootAttribute("Customers"));

                var reader = new StringReader(inputXml);

                using (reader)
                {
                    var customerDtos = (List<ImportCustomersDTO>)xmlSerializer.Deserialize(reader);

                    var customers = Mapper.Map<List<Customer>>(customerDtos);

                    context.AddRange(customers);

                    context.SaveChanges();

                    return $"Successfully imported {customers.Count}";
                }
            }
        }

        // Problem 03 - Import Cars
        public static string ImportCars(CarDealerContext context, string inputXml)
        {
            using (context)
            {
                var xmlSerializer = new XmlSerializer(typeof(List<ImportCarDTO>), new XmlRootAttribute("Cars"));

                var reader = new StringReader(inputXml);

                using (reader)
                {
                    var carDtos = (List<ImportCarDTO>)xmlSerializer.Deserialize(reader);

                    var cars = new List<Car>();
                    var partCars = new List<PartCar>();

                    foreach (var carDto in carDtos)
                    {
                        var car = new Car()
                        {
                            Make = carDto.Make,
                            Model = carDto.Model,
                            TravelledDistance = carDto.TravelledDistance,
                        };

                        var parts = carDto
                            .Parts
                            .Where(pdto => context
                                            .Parts
                                            .Any(p => p.Id == pdto.Id))
                            .Select(p => p.Id)
                            .Distinct();

                        foreach (var part in parts)
                        {
                            var partCar = new PartCar()
                            {
                                PartId = part,
                                Car = car
                            };

                            partCars.Add(partCar);
                        }

                        cars.Add(car);
                    }

                    context.AddRange(cars);

                    context.AddRange(partCars);

                    context.SaveChanges();

                    return $"Successfully imported {cars.Count}";
                }
            }
        }

        // Problem 02 - Import Parts
        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            using (context)
            {
                var xmlSerializer = new XmlSerializer(typeof(List<ImportPartDTO>), new XmlRootAttribute("Parts"));

                var reader = new StringReader(inputXml);

                using (reader)
                {
                    var partDtos = (List<ImportPartDTO>)xmlSerializer.Deserialize(reader);

                    var parts = Mapper.Map<List<Part>>(partDtos).Where(p => Enumerable.Range(context.Suppliers.Min(s => s.Id), context.Suppliers.Max(s => s.Id)).Contains(p.SupplierId)).ToList();

                    context.AddRange(parts);

                    context.SaveChanges();

                    return $"Successfully imported {parts.Count}";
                }
            }
        }

        // Problem 01 - Import Suppliers
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            using (context)
            {
                var xmlSerializer = new XmlSerializer(typeof(List<ImportSupplierDTO>), new XmlRootAttribute("Suppliers"));

                var reader = new StringReader(inputXml);

                using (reader)
                {
                    var supplierDtos = (List<ImportSupplierDTO>)xmlSerializer.Deserialize(reader);

                    var suppliers = Mapper.Map<List<Supplier>>(supplierDtos);

                    context.AddRange(suppliers);

                    context.SaveChanges();

                    return $"Successfully imported {suppliers.Count}";
                }
            }
        }

        // Initializing the Mapper
        private static void InitializeMapper()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile<CarDealerProfile>();
            });
        }

        // Reset Database to empty!
        private static void ResetDatabase(CarDealerContext db)
        {
            using (db)
            {
                db.Database.EnsureDeleted();
                Console.WriteLine("Db was successfully deleted!");

                db.Database.EnsureCreated();
                Console.WriteLine("Db was successfully created!");
            }
        }
    }
}
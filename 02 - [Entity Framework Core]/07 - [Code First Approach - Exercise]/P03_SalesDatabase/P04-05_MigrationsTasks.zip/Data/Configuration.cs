﻿namespace P03_SalesDatabase.Data
{
    internal static class Configuration
    {
        internal const string CONNECTION_STRING = @"Server=DESKTOP-10E0DVG\SQLEXPRESS;Database=SalesDb;Integrated Security=true;";
    }
}
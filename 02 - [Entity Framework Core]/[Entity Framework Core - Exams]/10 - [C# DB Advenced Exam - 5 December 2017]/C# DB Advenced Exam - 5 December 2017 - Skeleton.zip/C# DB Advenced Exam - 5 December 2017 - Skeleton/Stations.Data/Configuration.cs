﻿namespace Stations.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=.;Database=Station;Trusted_Connection=True";
    }
}
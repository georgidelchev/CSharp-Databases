﻿using Instagraph.Data;

namespace Instagraph.DataProcessor
{
    public class Serializer
    {
        public static string ExportUncommentedPosts(InstagraphContext context)
        {
            return null;
        }

        public static string ExportPopularUsers(InstagraphContext context)
        {
            return null;
        }

        public static string ExportCommentsOnPosts(InstagraphContext context)
        {
            return null;
        }
    }
}

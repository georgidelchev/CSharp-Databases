﻿using Instagraph.Data;

namespace Instagraph.DataProcessor
{

    public class Deserializer
    {
        private static string successMessage = "Successfully imported {0}.";
        private static string errorMessage = "Error: Invalid data.";

        public static string ImportPictures(InstagraphContext context, string jsonString)
        {
            return null;
        }

        public static string ImportUsers(InstagraphContext context, string jsonString)
        {
            return null;
        }

        public static string ImportFollowers(InstagraphContext context, string jsonString)
        {
            return null;
        }

        public static string ImportPosts(InstagraphContext context, string xmlString)
        {
            return null;
        }

        public static string ImportComments(InstagraphContext context, string xmlString)
        {
            return null;
        }
    }
}

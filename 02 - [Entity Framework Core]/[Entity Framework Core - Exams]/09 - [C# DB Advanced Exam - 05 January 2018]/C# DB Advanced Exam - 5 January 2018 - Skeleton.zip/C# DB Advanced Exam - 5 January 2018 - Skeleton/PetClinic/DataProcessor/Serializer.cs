﻿using PetClinic.Data;

namespace PetClinic.DataProcessor
{
    public class Serializer
    {
        public static string ExportAnimalsByOwnerPhoneNumber(PetClinicContext context, string phoneNumber)
        {
            return null;
        }

        public static string ExportAllProcedures(PetClinicContext context)
        {
            return null;
        }
    }
}
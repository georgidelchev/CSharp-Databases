﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Xml.Serialization;
using AutoMapper;
using CarDealer.Data;
using CarDealer.Dtos.Import;
using CarDealer.Models;

namespace CarDealer
{
    public class StartUp
    {
        private const string DATASETS_DIRECTORY_PATH = "../../../Datasets";


        private const string RESULTS_DIRECTORY_PATH = "../../../Datasets/Results";

        public static void Main(string[] args)
        {
            var db = new CarDealerContext();

            using (db)
            {
                // ResetDatabase(db);

                InitializeMapper();

                // Problem 01 - Import Suppliers
                //var inputXml = File.ReadAllText($"{DATASETS_DIRECTORY_PATH}/suppliers.xml");

                //Console.WriteLine(ImportSuppliers(db, inputXml));

                // Problem 02 - Import Parts
                var inputXml = File.ReadAllText($"{DATASETS_DIRECTORY_PATH}/parts.xml");

                Console.WriteLine(ImportParts(db, inputXml));
            }
        }

        // Problem 02 - Import Parts
        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            using (context)
            {
                var xmlSerializer = new XmlSerializer(typeof(List<ImportPartsDTO>), new XmlRootAttribute("Parts"));

                var reader = new StringReader(inputXml);

                using (reader)
                {
                    var partsDtos = (List<ImportPartsDTO>)xmlSerializer.Deserialize(reader);

                    var parts = Mapper.Map<List<Part>>(partsDtos).Where(p => Enumerable.Range(context.Suppliers.Min(s => s.Id), context.Suppliers.Max(s => s.Id)).Contains(p.SupplierId)).ToList();

                    context.AddRange(parts);

                    context.SaveChanges();

                    return $"Successfully imported {parts.Count}";
                }
            }
        }

        // Problem 01 - Import Suppliers
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            using (context)
            {
                var xmlSerializer = new XmlSerializer(typeof(List<ImportSuppliersDTO>), new XmlRootAttribute("Suppliers"));

                var reader = new StringReader(inputXml);

                using (reader)
                {
                    var suppliersDtos = (List<ImportSuppliersDTO>)xmlSerializer.Deserialize(reader);

                    var suppliers = Mapper.Map<List<Supplier>>(suppliersDtos);

                    context.AddRange(suppliers);

                    context.SaveChanges();

                    return $"Successfully imported {suppliers.Count}";
                }
            }
        }

        // Initializing the Mapper
        private static void InitializeMapper()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile<CarDealerProfile>();
            });
        }

        // Reset Database to empty!
        private static void ResetDatabase(CarDealerContext db)
        {
            using (db)
            {
                db.Database.EnsureDeleted();
                Console.WriteLine("Db was successfully deleted!");

                db.Database.EnsureCreated();
                Console.WriteLine("Db was successfully created!");
            }
        }
    }
}
﻿namespace BookShop.Data.Configurations
{
    internal static class ConnectionConfiguration
    {
        internal const string CONNECTION_STRING = @"Server=DESKTOP-10E0DVG\SQLEXPRESS;Database=BookShop;Integrated Security=true;";
    }
}
﻿using System;
using System.Linq;
using System.Text;
using BookShop.Data;
using BookShop.Initializer;
using BookShop.Models.Enums;

namespace BookShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new BookShopContext();

            using (db)
            {
                // DbInitializer.ResetDatabase(db);

                // Problem 02 - Age Restriction
                // var command = Console.ReadLine();
                // Console.WriteLine(GetBooksByAgeRestriction(db, command));


                // Problem 03 - Golden Books
                // Console.WriteLine(GetGoldenBooks(db));


                // Problem 04 - Books by Price
                //Console.WriteLine(GetBooksByPrice(db));
            }
        }

        // Problem 04 - Books by Price
        public static string GetBooksByPrice(BookShopContext context)
        {
            var sb = new StringBuilder();

            using (context)
            {
                var books = context
                    .Books
                    .Select(b => new
                    {
                        Title = b.Title,
                        Price = b.Price
                    })
                    .Where(b => b.Price > 40)
                    .OrderByDescending(b => b.Price)
                    .ToList();

                foreach (var book in books)
                {
                    sb.AppendLine($"{book.Title} - " +
                                  $"${book.Price}");
                }
            }

            return sb.ToString().Trim();
        }

        // Problem 03 - Golden Books
        public static string GetGoldenBooks(BookShopContext context)
        {
            var sb = new StringBuilder();

            using (context)
            {
                var books = context
                    .Books
                    .Where(b => b.Copies < 5000 && b.EditionType == EditionType.Gold)
                    .OrderBy(b => b.BookId)
                    .Select(b => b.Title)
                    .ToList();

                foreach (var book in books)
                {
                    sb.AppendLine(book);
                }
            }

            return sb.ToString().Trim();
        }

        // Problem 02 - Age Restriction
        public static string GetBooksByAgeRestriction(BookShopContext context,
            string command)
        {
            var sb = new StringBuilder();

            using (context)
            {
                var books = context
                    .Books
                    .Where(b => b.AgeRestriction == Enum.Parse<AgeRestriction>(command, true))
                    .Select(b => b.Title)
                    .OrderBy(b => b)
                    .ToList();

                foreach (var book in books)
                {
                    sb.AppendLine($"{book}");
                }
            }

            return sb.ToString().Trim();
        }
    }
}

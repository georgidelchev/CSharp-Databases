﻿using System;
using System.Linq;
using System.Text;
using BookShop.Data;
using BookShop.Initializer;
using BookShop.Models.Enums;

namespace BookShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new BookShopContext();

            using (db)
            {
                // DbInitializer.ResetDatabase(db);

                // Problem 02 - Age Restriction
                var command = Console.ReadLine();
                Console.WriteLine(GetBooksByAgeRestriction(db, command));
            }

        }

        // Problem 02 - Age Restriction

        public static string GetBooksByAgeRestriction(BookShopContext context,
            string command)
        {
            var sb = new StringBuilder();

            using (context)
            {
                var books = context
                    .Books
                    .Where(b => b.AgeRestriction == Enum.Parse<AgeRestriction>(command, true))
                    .Select(b => b.Title)
                    .OrderBy(b => b)
                    .ToList();

                foreach (var book in books)
                {
                    sb.AppendLine($"{book}");
                }
            }

            return sb.ToString().Trim();
        }
    }
}

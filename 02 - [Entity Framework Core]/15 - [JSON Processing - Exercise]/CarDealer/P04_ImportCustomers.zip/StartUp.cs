﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        private const string DATASETS_DIRECTORY_PATH = "../../../Datasets";

        private const string RESULTS_DIRECTORY_PATH = "../../../Datasets/Results";

        public static void Main(string[] args)
        {
            var db = new CarDealerContext();

            using (db)
            {
                InitializeMapper();

                //ResetDatabase(db);

                //Problem 01 - Import Suppliers
                //var jsonInput = File.ReadAllText($"{DATASETS_DIRECTORY_PATH}/suppliers.json");

                // Console.WriteLine(ImportSuppliers(db, jsonInput));

                // Problem 02 - Import Parts
                // var jsonInput = File.ReadAllText($"{DATASETS_DIRECTORY_PATH}/parts.json");

                // Console.WriteLine(ImportParts(db, jsonInput));

                // Problem 03 - Import Cars
                //var jsonInput = File.ReadAllText($"{DATASETS_DIRECTORY_PATH}/cars.json");

                //Console.WriteLine(ImportCars(db, jsonInput));

                // Problem 04 - Import Customers
                var jsonInput = File.ReadAllText($"{DATASETS_DIRECTORY_PATH}/customers.json");

                Console.WriteLine(ImportCustomers(db, jsonInput));
            }
        }

        public static string ImportCustomers(CarDealerContext context, string
            inputJson)
        {
            using (context)
            {
                var customers = JsonConvert.DeserializeObject<List<Customer>>(inputJson);

                context.AddRange(customers);

                context.SaveChanges();

                return $"Successfully imported {customers.Count}";
            }
        }

        public static string ImportCars(CarDealerContext context, string inputJson)
        {
            using (context)
            {
                var cars = JsonConvert.DeserializeObject<List<Car>>(inputJson);

                context.AddRange(cars);

                context.SaveChanges();

                return $"Successfully imported {cars.Count}";
            }
        }

        // Problem 02 - Import Parts
        public static string ImportParts(CarDealerContext context, string inputJson)
        {
            using (context)
            {
                var parts = JsonConvert.DeserializeObject<List<Part>>(inputJson)
                    .Where(p => Enumerable.Range(context.Suppliers
                                                        .Min(s => s.Id),
                                                 context.Suppliers
                                                        .Max(s => s.Id))
                                          .Contains(p.SupplierId))
                    .ToList();

                context.AddRange(parts);

                context.SaveChanges();

                return $"Successfully imported {parts.Count}";
            }
        }

        // Problem 01 - Import Suppliers
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            using (context)
            {
                var suppliers = JsonConvert.DeserializeObject<List<Supplier>>(inputJson);

                context.AddRange(suppliers);

                context.SaveChanges();

                return $"Successfully imported {suppliers.Count}";
            }
        }

        // Reset Database to empty!
        private static void ResetDatabase(CarDealerContext db)
        {
            using (db)
            {
                db.Database.EnsureDeleted();
                Console.WriteLine("Db was successfully deleted!");

                db.Database.EnsureCreated();
                Console.WriteLine("Db was successfully created!");
            }
        }

        // Initializing the Mapper
        private static void InitializeMapper()
        {
            Mapper.Initialize(cfg =>
            {
                cfg.AddProfile<CarDealerProfile>();
            });
        }
    }
}
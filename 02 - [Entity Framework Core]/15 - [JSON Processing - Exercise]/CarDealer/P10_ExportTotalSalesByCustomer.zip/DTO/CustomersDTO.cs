﻿using System;

namespace CarDealer.DTO
{
    public class CustomersDTO
    {
        public string Name { get; set; }

        public string BirthDate { get; set; }

        public bool IsYoungDriver { get; set; }
    }
}
﻿using System;
using System.IO;
using AutoMapper;
using System.Linq;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;
using System.Collections.Generic;
using Newtonsoft.Json.Serialization;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            var db = new ProductShopContext();

            using (db)
            {
                // ResetDatabase(db);

                // Problem 02 - Import Users
                // var inputJson = File.ReadAllText("../../../Datasets/users.json");

                // Console.WriteLine(ImportUsers(db, inputJson));

                // Problem 03 - Import Products
                // var inputJson = File.ReadAllText("../../../Datasets/products.json");

                // Console.WriteLine(ImportProducts(db, inputJson));

                // Problem 04 - Import Categories
                var inputJson = File.ReadAllText("../../../Datasets/categories.json");

                Console.WriteLine(ImportCategories(db, inputJson));
            }
        }

        // Problem 04 - Import Categories
        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            using (context)
            {
                var categories = JsonConvert.DeserializeObject<List<Category>>(inputJson)
                    .Where(c => c.Name != null)
                    .ToList();

                context.Categories.AddRange(categories);

                context.SaveChanges();

                return $"Successfully imported {categories.Count}";
            }
        }

        // Problem 03 - Import Products
        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            using (context)
            {
                var products = JsonConvert.DeserializeObject<List<Product>>(inputJson);

                context.Products.AddRange(products);

                context.SaveChanges();

                return $"Successfully imported {products.Count}";
            }
        }

        // Problem 02 - Import Users
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            using (context)
            {
                var serializerSettings = new JsonSerializerSettings()
                {
                    NullValueHandling = NullValueHandling.Ignore,
                    DefaultValueHandling = DefaultValueHandling.Ignore
                };

                var users = JsonConvert.DeserializeObject<List<User>>(inputJson, serializerSettings);

                context.Users.AddRange(users);

                context.SaveChanges();

                return $"Successfully imported {users.Count}";
            }
        }

        // Reset Database to empty!
        private static void ResetDatabase(ProductShopContext db)
        {
            using (db)
            {
                db.Database.EnsureDeleted();
                Console.WriteLine("Db was successfully deleted!");

                db.Database.EnsureCreated();
                Console.WriteLine("Db was successfully created!");
            }
        }
    }
}